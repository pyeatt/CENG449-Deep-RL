class Basis:
    def __init__(self, d, n):
        self.d = d
        self.n = n
